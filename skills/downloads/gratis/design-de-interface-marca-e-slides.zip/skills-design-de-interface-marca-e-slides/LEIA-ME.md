Skills grátis da VisionX. Descompacte em ~/.claude/skills/ (Windows: %USERPROFILE%\.claude\skills) e reinicie o Claude Code.
Cada skill traz o LICENSE do autor; mantenha o arquivo junto da pasta. Origem e licença de cada uma: NOTICES.md.
